insert into account(account_num,type,balance) values ('H12349876','savings',82563.74);
insert into account(account_num,type,balance) values ('A12349876','current',523.54);
insert into account(account_num,type,balance) values ('X12349876','savings',263.70);
insert into account(account_num,type,balance) values ('Z12349876','current',968963.62);