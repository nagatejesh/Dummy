package com.cognizant.loan;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Loan {

	@Id
	private String loanNum;
	
	private String type;
	
	private BigDecimal amount;
	
	private BigDecimal emi;
	
	private Integer tenure;
	
	public Loan() {
		// TODO Auto-generated constructor stub
	}

	public Loan(String loanNum, String type, BigDecimal amount, BigDecimal emi, Integer tenure) {
		super();
		this.loanNum = loanNum;
		this.type = type;
		this.amount = amount;
		this.emi = emi;
		this.tenure = tenure;
	}

	public String getLoanNum() {
		return loanNum;
	}

	public void setLoanNum(String loanNum) {
		this.loanNum = loanNum;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getEmi() {
		return emi;
	}

	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}

	public Integer getTenure() {
		return tenure;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	@Override
	public String toString() {
		return "Loan [loanNum=" + loanNum + ", type=" + type + ", amount=" + amount + ", emi=" + emi + ", tenure="
				+ tenure + "]";
	}
	
}
