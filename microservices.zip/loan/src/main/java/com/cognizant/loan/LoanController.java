package com.cognizant.loan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoanController {

	@Autowired
	private LoanJpaRepository repo;
	
	@GetMapping("/loans/{id}")
	public Loan getLoan(@PathVariable String id) {
		return repo.findById(id).get();
	}
	
}
