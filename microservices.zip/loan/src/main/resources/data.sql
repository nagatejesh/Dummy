insert into loan (loan_num,type,amount,emi,tenure) values ('A8765','car',360000.00,20000.00,18)
insert into loan (loan_num,type,amount,emi,tenure) values ('X8765','two-wheeler',120000.00,10000.00,12)
insert into loan (loan_num,type,amount,emi,tenure) values ('Z8765','house',2400000.00,100000.00,24)
insert into loan (loan_num,type,amount,emi,tenure) values ('Q8765','education',180000.00,5000.00,36)